import { CheckReachabilityOptions, RecursivePartial } from 'clientnode/type';
import { PluginHandler } from 'web-node/type';
import { Configuration, Service, ServicePromises, Services } from './type';
/**
 * Launches an application server und triggers all some pluginable hooks on
 * an event.
 */
export declare class Nginx implements PluginHandler {
    /**
     * Start nginx's child process and return a Promise which observes this
     * service.
     * @param servicePromises - An object with stored service promise
     * instances.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns A promise which correspond to the plugin specific continues
     * service.
     */
    static loadService(servicePromises: Omit<ServicePromises, 'nginx'>, services: Services, configuration: Configuration): Promise<null | Service>;
    /**
     * Application will be closed soon.
     * @param services - An object with stored service instances.
     * @param configuration - Mutable by plugins extended configuration object.
     *
     * @returns Given object of services.
     */
    static shouldExit(services: Services, configuration: Configuration): Promise<Services>;
    /**
     * Check if a nginx server is currently (not) running.
     * @param serverConfiguration - Mutable by plugins extended configuration
     * object.
     * @param inverse - Boolean indicating if we should check for reachability
     * or un-reachability.
     * @param givenOptions - Tools reachability options to configure how to
     * check for reachability.
     *
     * @returns A promise which will be resolved if a request to given url has
     * (not) finished. Otherwise returned promise will be rejected.
     */
    static checkReachability(serverConfiguration: Configuration['applicationServer'], inverse?: boolean, givenOptions?: RecursivePartial<CheckReachabilityOptions>): Promise<Response | Error | null | Promise<Error | null>>;
}
export default Nginx;

if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;import { exec as __WEBPACK_EXTERNAL_MODULE_child_process_exec__, spawn as __WEBPACK_EXTERNAL_MODULE_child_process_spawn__ } from "child_process";
import { CLOSE_EVENT_NAMES as __WEBPACK_EXTERNAL_MODULE_clientnode_CLOSE_EVENT_NAMES__, Logger as __WEBPACK_EXTERNAL_MODULE_clientnode_Logger__, checkReachability as __WEBPACK_EXTERNAL_MODULE_clientnode_checkReachability__, checkUnreachability as __WEBPACK_EXTERNAL_MODULE_clientnode_checkUnreachability__, getProcessCloseHandler as __WEBPACK_EXTERNAL_MODULE_clientnode_getProcessCloseHandler__, represent as __WEBPACK_EXTERNAL_MODULE_clientnode_represent__ } from "clientnode";
import { Agent as __WEBPACK_EXTERNAL_MODULE_https_Agent__ } from "https";

;// external "child_process"

;// external "clientnode"

;// external "https"

;// ./index.ts
// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module nginx-web-node-plugin *//* !
    region header
    [Project page](https://tsickert.com/nginx-web-node-plugin)

    Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
function _typeof(o){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter(function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable})),t.push.apply(t,o)}return t}function _objectSpread(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?ownKeys(Object(t),!0).forEach(function(r){_defineProperty(e,r,t[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):ownKeys(Object(t)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))})}return e}function _defineProperty(e,r,t){return(r=_toPropertyKey(r))in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}function _toPropertyKey(t){var i=_toPrimitive(t,"string");return"symbol"==_typeof(i)?i:i+""}function _toPrimitive(t,r){if("object"!=_typeof(t)||!t)return t;var e=t[Symbol.toPrimitive];if(void 0!==e){var i=e.call(t,r||"default");if("object"!=_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===r?String:Number)(t)}function _regenerator(){/*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */var e,t,r="function"==typeof Symbol?Symbol:{},n=r.iterator||"@@iterator",o=r.toStringTag||"@@toStringTag";function i(r,n,o,i){var c=n&&n.prototype instanceof Generator?n:Generator,u=Object.create(c.prototype);return _regeneratorDefine2(u,"_invoke",function(r,n,o){var i,c,u,f=0,p=o||[],y=!1,G={p:0,n:0,v:e,a:d,f:d.bind(e,4),d:function d(t,r){return i=t,c=0,u=e,G.n=r,a}};function d(r,n){for(c=r,u=n,t=0;!y&&f&&!o&&t<p.length;t++){var o,i=p[t],d=G.p,l=i[2];r>3?(o=l===n)&&(u=i[(c=i[4])?5:(c=3,3)],i[4]=i[5]=e):i[0]<=d&&((o=r<2&&d<i[1])?(c=0,G.v=n,G.n=i[1]):d<l&&(o=r<3||i[0]>n||n>l)&&(i[4]=r,i[5]=n,G.n=l,c=0))}if(o||r>1)return a;throw y=!0,n}return function(o,p,l){if(f>1)throw TypeError("Generator is already running");for(y&&1===p&&d(p,l),c=p,u=l;(t=c<2?e:u)||!y;){i||(c?c<3?(c>1&&(G.n=-1),d(c,u)):G.n=u:G.v=u);try{if(f=2,i){if(c||(o="next"),t=i[o]){if(!(t=t.call(i,u)))throw TypeError("iterator result is not an object");if(!t.done)return t;u=t.value,c<2&&(c=0)}else 1===c&&(t=i.return)&&t.call(i),c<2&&(u=TypeError("The iterator does not provide a '"+o+"' method"),c=1);i=e}else if((t=(y=G.n<0)?u:r.call(n,G))!==a)break}catch(t){i=e,c=1,u=t}finally{f=1}}return{value:t,done:y}}}(r,o,i),!0),u}var a={};function Generator(){}function GeneratorFunction(){}function GeneratorFunctionPrototype(){}t=Object.getPrototypeOf;var c=[][n]?t(t([][n]())):(_regeneratorDefine2(t={},n,function(){return this}),t),u=GeneratorFunctionPrototype.prototype=Generator.prototype=Object.create(c);function f(e){return Object.setPrototypeOf?Object.setPrototypeOf(e,GeneratorFunctionPrototype):(e.__proto__=GeneratorFunctionPrototype,_regeneratorDefine2(e,o,"GeneratorFunction")),e.prototype=Object.create(u),e}return GeneratorFunction.prototype=GeneratorFunctionPrototype,_regeneratorDefine2(u,"constructor",GeneratorFunctionPrototype),_regeneratorDefine2(GeneratorFunctionPrototype,"constructor",GeneratorFunction),GeneratorFunction.displayName="GeneratorFunction",_regeneratorDefine2(GeneratorFunctionPrototype,o,"GeneratorFunction"),_regeneratorDefine2(u),_regeneratorDefine2(u,o,"Generator"),_regeneratorDefine2(u,n,function(){return this}),_regeneratorDefine2(u,"toString",function(){return"[object Generator]"}),(_regenerator=function _regenerator(){return{w:i,m:f}})()}function _regeneratorDefine2(e,r,n,t){var i=Object.defineProperty;try{i({},"",{})}catch(e){i=0}_regeneratorDefine2=function _regeneratorDefine(e,r,n,t){function o(r,n){_regeneratorDefine2(e,r,function(e){return this._invoke(r,n,e)})}r?i?i(e,r,{value:n,enumerable:!t,configurable:!t,writable:!t}):e[r]=n:(o("next",0),o("throw",1),o("return",2))},_regeneratorDefine2(e,r,n,t)}function _createForOfIteratorHelper(r,e){var t="undefined"!=typeof Symbol&&r[Symbol.iterator]||r["@@iterator"];if(!t){if(Array.isArray(r)||(t=_unsupportedIterableToArray(r))||e&&r&&"number"==typeof r.length){t&&(r=t);var _n=0,F=function F(){};return{s:F,n:function n(){return _n>=r.length?{done:!0}:{done:!1,value:r[_n++]}},e:function e(r){throw r},f:F}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var o,a=!0,u=!1;return{s:function s(){t=t.call(r)},n:function n(){var r=t.next();return a=r.done,r},e:function e(r){u=!0,o=r},f:function f(){try{a||null==t.return||t.return()}finally{if(u)throw o}}}}function _unsupportedIterableToArray(r,a){if(r){if("string"==typeof r)return _arrayLikeToArray(r,a);var t={}.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?_arrayLikeToArray(r,a):void 0}}function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=Array(a);e<a;e++)n[e]=r[e];return n}function asyncGeneratorStep(n,t,e,r,o,a,c){try{var i=n[a](c),u=i.value}catch(n){return void e(n)}i.done?t(u):Promise.resolve(u).then(r,o)}function _asyncToGenerator(n){return function(){var t=this,e=arguments;return new Promise(function(r,o){var a=n.apply(t,e);function _next(n){asyncGeneratorStep(a,r,o,_next,_throw,"next",n)}function _throw(n){asyncGeneratorStep(a,r,o,_next,_throw,"throw",n)}_next(void 0)})}};// endregion
var log=new __WEBPACK_EXTERNAL_MODULE_clientnode_Logger__({name:"web-node.nginx"});// region plugins/classes
/**
 * Launches an application server und triggers all some pluginable hooks on
 * an event.
 */// region api
/**
 * Start nginx's child process and return a Promise which observes this
 * service.
 * @param state - Application state.
 * @param state.configuration - Applications configuration.
 * @param state.configuration.applicationServer - Plugins configuration.
 * @param state.services - An object with stored service instances.
 * @returns A mapping to promises which correspond to the plugin specific
 * continues services.
 */var loadService=/*#__PURE__*/function(){var _loadService=_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(_ref){var configuration,services,nginx,promise,_t;return _regenerator().w(function(_context){while(1)switch(_context.p=_context.n){case 0:configuration=_ref.configuration.applicationServer,services=_ref.services;if(!services.nginx){_context.n=1;break}return _context.a(2,null);case 1:nginx=__WEBPACK_EXTERNAL_MODULE_child_process_spawn__("nginx",[],{cwd:process.cwd(),env:process.env,shell:true,stdio:"inherit"});services.nginx=nginx;nginx.reload=function(){return new Promise(function(resolve,reject){return __WEBPACK_EXTERNAL_MODULE_child_process_exec__("nginx -s reload",function(error,standardOutput,standardErrorOutput){if(error){error.standardErrorOutput=standardErrorOutput;/*
                            eslint-disable
                            @typescript-eslint/prefer-promise-reject-errors
                        */reject(error);/*
                            eslint-enable
                            @typescript-eslint/prefer-promise-reject-errors
                        */}else resolve(standardOutput)})})};promise=new Promise(function(resolve,reject){var _iterator=_createForOfIteratorHelper(__WEBPACK_EXTERNAL_MODULE_clientnode_CLOSE_EVENT_NAMES__),_step;try{for(_iterator.s();!(_step=_iterator.n()).done;){var closeEventName=_step.value;nginx.on(closeEventName,__WEBPACK_EXTERNAL_MODULE_clientnode_getProcessCloseHandler__(resolve,configuration.proxy.optional?resolve:reject,{reason:nginx,process:nginx}))}}catch(err){_iterator.e(err)}finally{_iterator.f()}});_context.p=2;_context.n=3;return checkReachability(configuration);case 3:_context.n=6;break;case 4:_context.p=4;_t=_context.v;if(!configuration.proxy.optional){_context.n=5;break}void log.warn("Nginx couldn't be started (or at least","\"".concat(configuration.proxy.url,"\" could not be reached) but was"),"marked as optional.");services.nginx=null;promise=null;_context.n=6;break;case 5:throw new Error("Could not acknowledge that nginx is running because "+"\"".concat(configuration.proxy.url,"\" is not reachable: ")+__WEBPACK_EXTERNAL_MODULE_clientnode_represent__(_t),{cause:_t});case 6:return _context.a(2,{nginx:promise})}},_callee,null,[[2,4]])}));function loadService(_x){return _loadService.apply(this,arguments)}return loadService}();/**
 * Application will be closed soon.
 * @param state - Application state.
 * @param state.configuration - Applications configuration.
 * @param state.services - Application services.
 * @returns Given object of services.
 */var shouldExit=/*#__PURE__*/function(){var _shouldExit=_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2(_ref2){var configuration,services;return _regenerator().w(function(_context2){while(1)switch(_context2.n){case 0:configuration=_ref2.configuration,services=_ref2.services;if(!(services.nginx!==null)){_context2.n=1;break}services.nginx.kill("SIGINT");_context2.n=1;return checkReachability(configuration.applicationServer,true);case 1:delete services.nginx;case 2:return _context2.a(2)}},_callee2)}));function shouldExit(_x2){return _shouldExit.apply(this,arguments)}return shouldExit}();// endregion
// region helper
/**
 * Check if a nginx server is currently (not) running.
 * @param serverConfiguration - Mutable by plugins extended configuration
 * object.
 * @param inverse - Boolean indicating if we should check for reachability or
 * un-reachability.
 * @param givenOptions - Tools reachability options to configure how to check
 * for reachability.
 * @returns A promise which will be resolved if a request to given url has
 * (not) finished, otherwise returned promise will be rejected.
 */var checkReachability=function checkReachability(serverConfiguration,inverse,givenOptions){if(inverse===void 0){inverse=false}if(givenOptions===void 0){givenOptions={}}if(serverConfiguration.proxy.url){var isSSL=serverConfiguration.proxy.url.startsWith("https://");var options=_objectSpread({options:_objectSpread({redirect:"manual"},isSSL?{agent:new __WEBPACK_EXTERNAL_MODULE_https_Agent__({rejectUnauthorized:false})}:{}),pollIntervalInSeconds:.1,statusCodes:[100,101,102,200,201,202,203,204,205,206,207,208,226,300,301,302,303,304,305,306,307,308],timeoutInSeconds:3,wait:true},givenOptions);return(inverse?__WEBPACK_EXTERNAL_MODULE_clientnode_checkUnreachability__:__WEBPACK_EXTERNAL_MODULE_clientnode_checkReachability__)(serverConfiguration.proxy.url,options)}return Promise.resolve(null)};// endregion
var nginx={loadService:loadService,shouldExit:shouldExit,checkReachability:checkReachability};/* harmony default export */ const index = (nginx);// endregion
export { checkReachability, index as default, loadService, log, nginx, shouldExit };

if(typeof window==='undefined'||window===null)var window=(typeof globalThis==='undefined'||globalThis===null)?{}:globalThis;import { exec as __WEBPACK_EXTERNAL_MODULE_child_process_exec__, spawn as __WEBPACK_EXTERNAL_MODULE_child_process_spawn__ } from "child_process";
import { CLOSE_EVENT_NAMES as __WEBPACK_EXTERNAL_MODULE_clientnode_CLOSE_EVENT_NAMES__, Logger as __WEBPACK_EXTERNAL_MODULE_clientnode_Logger__, checkReachability as __WEBPACK_EXTERNAL_MODULE_clientnode_checkReachability__, checkUnreachability as __WEBPACK_EXTERNAL_MODULE_clientnode_checkUnreachability__, getProcessCloseHandler as __WEBPACK_EXTERNAL_MODULE_clientnode_getProcessCloseHandler__, represent as __WEBPACK_EXTERNAL_MODULE_clientnode_represent__ } from "clientnode";
import { Agent as __WEBPACK_EXTERNAL_MODULE_https_Agent__ } from "https";

;// external "child_process"

;// external "clientnode"

;// external "https"

;// ./index.ts
// #!/usr/bin/env babel-node
// -*- coding: utf-8 -*-
/** @module nginx-web-node-plugin *//* !
    region header
    [Project page](https://tsickert.com/nginx-web-node-plugin)

    Copyright Torben Sickert (info["~at~"]tsickert.com) 16.12.2012

    License
    -------

    This library written by Torben Sickert stands under a creative commons
    naming 3.0 unported license.
    See https://creativecommons.org/licenses/by/3.0/deed.de
    endregion
*/// region imports
function _typeof(o){"@babel/helpers - typeof";return _typeof="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o},_typeof(o)}function ownKeys(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var o=Object.getOwnPropertySymbols(e);r&&(o=o.filter(function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable})),t.push.apply(t,o)}return t}function _objectSpread(r){for(var t=1;t<arguments.length;t++){var o=null!=arguments[t]?arguments[t]:{};t%2?ownKeys(Object(o),!0).forEach(function(t){_defineProperty(r,t,o[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(r,Object.getOwnPropertyDescriptors(o)):ownKeys(Object(o)).forEach(function(e){Object.defineProperty(r,e,Object.getOwnPropertyDescriptor(o,e))})}return r}function _defineProperty(r,t,o){return(t=_toPropertyKey(t))in r?Object.defineProperty(r,t,{value:o,enumerable:!0,configurable:!0,writable:!0}):r[t]=o,r}function _toPropertyKey(r){var o=_toPrimitive(r,"string");return"symbol"==_typeof(o)?o:o+""}function _toPrimitive(t,e){if("object"!=_typeof(t)||!t)return t;var r;if("undefined"!=typeof Symbol&&void 0!==(r=t[Symbol.toPrimitive])){var i=r.call(t,e||"default");if("object"!=_typeof(i))return i;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===e?String:Number)(t)}function _regenerator(){/*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */var r,e,o="function"==typeof Symbol?Symbol:{},n=o.iterator||"@@iterator",a=o.toStringTag||"@@toStringTag";function i(o,n,a,i){var u=n&&n.prototype instanceof Generator?n:Generator,f=Object.create(u.prototype);return _regeneratorDefine2(f,"_invoke",function(t,o,n){var a,i,u,f=0,p=n||[],y=!1,G={p:0,n:0,v:r,a:l,f:l.bind(r,4),d:function d(t,e){return a=t,i=0,u=r,G.n=e,c}};function l(t,o){for(i=t,u=o,e=0;!y&&f&&!n&&e<p.length;e++){var n,a=p[e],l=G.p,F=a[2];t>3?(n=F===o)&&(u=a[(i=a[4])?5:(i=3,3)],a[4]=a[5]=r):a[0]<=l&&((n=t<2&&l<a[1])?(i=0,G.v=o,G.n=a[1]):l<F&&(n=t<3||a[0]>o||o>F)&&(a[4]=t,a[5]=o,G.n=F,i=0))}if(n||t>1)return c;throw y=!0,o}return function(n,p,F){if(f>1)throw TypeError("Generator is already running");for(y&&1===p&&l(p,F),i=p,u=F;(e=i<2?r:u)||!y;){a||(i?i<3?(i>1&&(G.n=-1),l(i,u)):G.n=u:G.v=u);try{if(f=2,a){if(i||(n="next"),e=a[n]){if(!(e=e.call(a,u)))throw TypeError("iterator result is not an object");if(!e.done)return e;u=e.value,i<2&&(i=0)}else 1===i&&(e=a.return)&&e.call(a),i<2&&(u=TypeError("The iterator does not provide a '"+n+"' method"),i=1);a=r}else if((e=(y=G.n<0)?u:t.call(o,G))!==c)break}catch(t){a=r,i=1,u=t}finally{f=1}}return{value:e,done:y}}}(o,a,i),!0),f}var c={};function Generator(){}function GeneratorFunction(){}function GeneratorFunctionPrototype(){}e=Object.getPrototypeOf;var u=[][n]?e(e([][n]())):(_regeneratorDefine2(e={},n,function(){return this}),e),f=GeneratorFunctionPrototype.prototype=Generator.prototype=Object.create(u);function p(r){return Object.setPrototypeOf?Object.setPrototypeOf(r,GeneratorFunctionPrototype):(r.__proto__=GeneratorFunctionPrototype,_regeneratorDefine2(r,a,"GeneratorFunction")),r.prototype=Object.create(f),r}return GeneratorFunction.prototype=GeneratorFunctionPrototype,_regeneratorDefine2(f,"constructor",GeneratorFunctionPrototype),_regeneratorDefine2(GeneratorFunctionPrototype,"constructor",GeneratorFunction),GeneratorFunction.displayName="GeneratorFunction",_regeneratorDefine2(GeneratorFunctionPrototype,a,"GeneratorFunction"),_regeneratorDefine2(f),_regeneratorDefine2(f,a,"Generator"),_regeneratorDefine2(f,n,function(){return this}),_regeneratorDefine2(f,"toString",function(){return"[object Generator]"}),(_regenerator=function _regenerator(){return{w:i,m:p}})()}function _regeneratorDefine2(e,r,n,t){var i=Object.defineProperty;try{i({},"",{})}catch(e){i=0}_regeneratorDefine2=function _regeneratorDefine(e,r,n,t){function o(r,n){_regeneratorDefine2(e,r,function(e){return this._invoke(r,n,e)})}r?i?i(e,r,{value:n,enumerable:!t,configurable:!t,writable:!t}):e[r]=n:(o("next",0),o("throw",1),o("return",2))},_regeneratorDefine2(e,r,n,t)}function _createForOfIteratorHelper(e,t){var _n="undefined"!=typeof Symbol&&e[Symbol.iterator]||e["@@iterator"];if(!_n){if(Array.isArray(e)||(_n=_unsupportedIterableToArray(e))||t&&e&&"number"==typeof e.length){_n&&(e=_n);var o=0,F=function F(){};return{s:F,n:function n(){return o>=e.length?{done:!0}:{done:!1,value:e[o++]}},e:function e(r){throw r},f:F}}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}var a,u,i=!0;return{s:function s(){_n=_n.call(e)},n:function n(){i=!0;var r=_n.next();return r.done?{done:!0}:{value:r.value,done:i=!1}},e:function e(r){a=!0,u=r},f:function f(){try{i||null==_n.return||_n.return()}finally{if(a)throw u}}}}function _unsupportedIterableToArray(t,e){if(t){if("string"==typeof t)return _arrayLikeToArray(t,e);var o={}.toString.call(t).slice(8,-1);return"Object"===o&&t.constructor&&(o=t.constructor.name),"Map"===o||"Set"===o?Array.from(t):"Arguments"===o||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o)?_arrayLikeToArray(t,e):void 0}}function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=Array(a);e<a;e++)n[e]=r[e];return n}function asyncGeneratorStep(n,t,e,r,o,a,c){try{var i=n[a](c),u=i.value}catch(n){return void e(n)}i.done?t(u):Promise.resolve(u).then(r,o)}function _asyncToGenerator(n){return function(){var t=this,e=arguments;return new Promise(function(r,o){var a=n.apply(t,e);function _next(n){asyncGeneratorStep(a,r,o,_next,_throw,"next",n)}function _throw(n){asyncGeneratorStep(a,r,o,_next,_throw,"throw",n)}_next(void 0)})}};// endregion
var log=new __WEBPACK_EXTERNAL_MODULE_clientnode_Logger__({name:"web-node.nginx"});// region plugins/classes
/**
 * Launches an application server und triggers all some pluginable hooks on
 * an event.
 */// region api
/**
 * Start nginx's child process and return a Promise which observes this
 * service.
 * @param state - Application state.
 * @param state.configuration - Applications configuration.
 * @param state.configuration.applicationServer - Plugins configuration.
 * @param state.services - An object with stored service instances.
 * @returns A mapping to promises which correspond to the plugin specific
 * continues services.
 */var loadService=/*#__PURE__*/function(){var _loadService=_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee(_ref){var configuration,services,nginx,promise,_t;return _regenerator().w(function(_context){while(1)switch(_context.p=_context.n){case 0:configuration=_ref.configuration.applicationServer,services=_ref.services;if(!services.nginx){_context.n=1;break}return _context.a(2,null);case 1:nginx=__WEBPACK_EXTERNAL_MODULE_child_process_spawn__("nginx",[],{cwd:process.cwd(),env:process.env,shell:true,stdio:"inherit"});services.nginx=nginx;nginx.reload=function(){return new Promise(function(resolve,reject){return __WEBPACK_EXTERNAL_MODULE_child_process_exec__("nginx -s reload",{env:process.env},function(error,standardOutput,standardErrorOutput){if(error){error.standardErrorOutput=standardErrorOutput;/*
                            eslint-disable
                            @typescript-eslint/prefer-promise-reject-errors
                        */reject(error);/*
                            eslint-enable
                            @typescript-eslint/prefer-promise-reject-errors
                        */}else resolve(standardOutput)})})};promise=new Promise(function(resolve,reject){var _iterator=_createForOfIteratorHelper(__WEBPACK_EXTERNAL_MODULE_clientnode_CLOSE_EVENT_NAMES__),_step;try{for(_iterator.s();!(_step=_iterator.n()).done;){var closeEventName=_step.value;nginx.on(closeEventName,__WEBPACK_EXTERNAL_MODULE_clientnode_getProcessCloseHandler__(resolve,configuration.proxy.optional?resolve:reject,{reason:nginx,process:nginx}))}}catch(err){_iterator.e(err)}finally{_iterator.f()}});_context.p=2;_context.n=3;return checkReachability(configuration);case 3:_context.n=6;break;case 4:_context.p=4;_t=_context.v;if(!configuration.proxy.optional){_context.n=5;break}void log.warn("Nginx couldn't be started (or at least","\"".concat(configuration.proxy.url,"\" could not be reached) but was"),"marked as optional.");services.nginx=null;promise=null;_context.n=6;break;case 5:throw new Error("Could not acknowledge that nginx is running because "+"\"".concat(configuration.proxy.url,"\" is not reachable: ")+__WEBPACK_EXTERNAL_MODULE_clientnode_represent__(_t),{cause:_t});case 6:return _context.a(2,{nginx:promise})}},_callee,null,[[2,4]])}));function loadService(_x){return _loadService.apply(this,arguments)}return loadService}();/**
 * Application will be closed soon.
 * @param state - Application state.
 * @param state.configuration - Applications configuration.
 * @param state.services - Application services.
 * @returns Given object of services.
 */var shouldExit=/*#__PURE__*/function(){var _shouldExit=_asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2(_ref2){var _services$nginx;var configuration,services;return _regenerator().w(function(_context2){while(1)switch(_context2.n){case 0:configuration=_ref2.configuration,services=_ref2.services;if(!((_services$nginx=services.nginx)!==null&&_services$nginx!==void 0&&_services$nginx.kill)){_context2.n=1;break}services.nginx.kill("SIGINT");_context2.n=1;return checkReachability(configuration.applicationServer,true);case 1:delete services.nginx;case 2:return _context2.a(2)}},_callee2)}));function shouldExit(_x2){return _shouldExit.apply(this,arguments)}return shouldExit}();// endregion
// region helper
/**
 * Check if a nginx server is currently (not) running.
 * @param serverConfiguration - Mutable by plugins extended configuration
 * object.
 * @param inverse - Boolean indicating if we should check for reachability or
 * un-reachability.
 * @param givenOptions - Tools reachability options to configure how to check
 * for reachability.
 * @returns A promise which will be resolved if a request to given url has
 * (not) finished, otherwise returned promise will be rejected.
 */var checkReachability=function checkReachability(serverConfiguration,inverse,givenOptions){if(inverse===void 0){inverse=false}if(givenOptions===void 0){givenOptions={}}if(serverConfiguration.proxy.url){var isSSL=serverConfiguration.proxy.url.startsWith("https://");var options=_objectSpread({options:_objectSpread({redirect:"manual"},isSSL?{agent:new __WEBPACK_EXTERNAL_MODULE_https_Agent__({rejectUnauthorized:false})}:{}),pollIntervalInSeconds:.1,statusCodes:[100,101,102,200,201,202,203,204,205,206,207,208,226,300,301,302,303,304,305,306,307,308],timeoutInSeconds:3,wait:true},givenOptions);return(inverse?__WEBPACK_EXTERNAL_MODULE_clientnode_checkUnreachability__:__WEBPACK_EXTERNAL_MODULE_clientnode_checkReachability__)(serverConfiguration.proxy.url,options)}return Promise.resolve(null)};// endregion
var nginx={loadService:loadService,shouldExit:shouldExit,checkReachability:checkReachability};/* harmony default export */ const index = (nginx);// endregion
export { checkReachability, index as default, loadService, log, nginx, shouldExit };

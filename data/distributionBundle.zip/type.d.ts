/// <reference types="node" />
import { ChildProcess } from 'child_process';
import { Mapping, ProcessCloseReason } from 'clientnode/type';
import { Configuration as BaseConfiguration, Services as BaseServices, ServicePromises as BaseServicePromises } from 'application-server-web-node-plugin/type';
import { ServicePromisesState as BaseServicePromisesState, ServicesState as BaseServicesState } from 'web-node/type';
export declare type Configuration<PluginConfigurationType = Mapping<unknown>> = BaseConfiguration<{
    applicationServer: {
        proxy: {
            optional: boolean;
            logFilePath: {
                access: string;
                error: string;
            };
            ports: {
                backend: Mapping<number>;
            };
        };
    };
}> & PluginConfigurationType;
export interface ServiceProcess extends ChildProcess {
    reload(): Promise<string>;
}
export declare type ServicePromises<Type = Mapping<unknown>> = BaseServicePromises<{
    nginx: Promise<ProcessCloseReason>;
}> & Type;
export declare type Services<Type = Mapping<unknown>> = BaseServices<{
    nginx: null | ServiceProcess;
}> & Type;
export declare type ServicesState = BaseServicesState<undefined, Configuration, Services>;
export declare type ServicePromisesState = BaseServicePromisesState<undefined, Configuration, Services, ServicePromises>;

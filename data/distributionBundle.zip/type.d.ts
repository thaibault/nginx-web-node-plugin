/// <reference types="node" />
import { ChildProcess } from 'child_process';
import { Mapping, ProcessCloseReason } from 'clientnode/type';
import { Configuration as BaseConfiguration, Services as BaseServices, ServicePromises as BaseServicePromises } from 'application-server-web-node-plugin/type';
import { Service as BaseService } from 'web-node/type';
export declare type Configuration<PluginConfigurationType = Mapping<unknown>> = BaseConfiguration<{
    applicationServer: {
        proxy: {
            optional: boolean;
            logFilePath: {
                access: string;
                error: string;
            };
            ports: {
                backend: Mapping<number>;
            };
        };
    };
}> & PluginConfigurationType;
export interface Service extends BaseService {
    name: 'nginx';
    promise: null | Promise<ProcessCloseReason>;
}
export interface ServiceProcess extends ChildProcess {
    reload(): Promise<string>;
}
export declare type ServicePromises<ServicePromiseType = Mapping<unknown>> = BaseServicePromises<{
    nginx: Promise<ProcessCloseReason>;
}> & ServicePromiseType;
export declare type Services<ServiceType = Mapping<unknown>> = BaseServices<{
    nginx: null | ServiceProcess;
}> & ServiceType;
